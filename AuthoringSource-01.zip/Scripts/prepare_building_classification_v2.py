from pathlib import Path
import copy, hashlib, json, re, shutil, uuid, zipfile

R = Path(__file__).resolve().parents[1]
NAME = "GPT's Buckingham Fountain"
SOURCE = Path('C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II/StreamingData~') / (NAME + '.cok')
EXPECTED = '53b73b19e8af32e54493a9ccfba58d54dfb31d315a57a71c81e3afdfb53a3990'
ROOT_ENTRY = 'ACMBuckinghamFountainV1_7af8431e49336acc76bdf3386b66a6c5.Prefab'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SOURCE) == EXPECTED
backup = R / 'Archive/BeforeBuildingClassification20261024'
backup.mkdir(exist_ok=False)
shutil.copy2(SOURCE, backup / SOURCE.name)
outdir = R / 'Release/BuildingV2'
outdir.mkdir(parents=True, exist_ok=False)

def decode(data):
    return json.loads(re.sub(r'\$fstrref:"([^"]+)"', r'"ASSETREF:\1"', data.decode('utf-8-sig')))

def encode(data):
    text = json.dumps(data, indent=4, ensure_ascii=False)
    return re.sub(r'"ASSETREF:([^"]+)"', r'$fstrref:"\1"', text).encode('utf-8')

with zipfile.ZipFile(SOURCE) as z:
    entries = {n: z.read(n) for n in z.namelist()}
old = decode(entries[ROOT_ENTRY])
new = copy.deepcopy(old)
assert old['$type'] == '0|Game.Prefabs.StaticObjectPrefab, Game'
new['$type'] = '0|Game.Prefabs.BuildingPrefab, Game'
new['name'] = NAME
new['m_AccessType'] = 7
new['m_LotWidth'] = 11
new['m_LotDepth'] = 11
components = new['components']['$rcontent']
assert len(components) == 2
assert len(components[0]['m_Effects']['$rcontent']) == 56
components.append({'$id': 67, '$type': '14|Game.Prefabs.PlaceableObject, Game',
                   'name': 'PlaceableObject', 'active': True,
                   'm_ConstructionCost': 0, 'm_XPReward': 0})
new['components']['$rlength'] = len(components)
aliases = components[1]['m_PrefabIdentifiers']
aliases['$rcontent'].append({'$id': 68, '$type': 11, 'm_Name': old['name'],
                            'm_Type': 'StaticObjectPrefab',
                            'm_Hash': '90a3b77f8fbdf731a8d9e556f7b85d7a'})
aliases['$rlength'] = len(aliases['$rcontent'])
assert new['m_Meshes'] == old['m_Meshes']
assert new['components']['$rcontent'][0] == old['components']['$rcontent'][0]
entries[ROOT_ENTRY] = encode(new)
entries['package.deps.cid'] = uuid.uuid4().hex.encode()
out = outdir / (NAME + '.cok')
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_STORED) as z:
    for n, data in entries.items():
        z.writestr(n, data)
with zipfile.ZipFile(SOURCE) as a, zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    changed = [n for n in a.namelist() if a.read(n) != z.read(n)]
    assert set(changed) == {ROOT_ENTRY, 'package.deps.cid'}
    assert decode(z.read(ROOT_ENTRY)) == new
    deps = json.loads(z.read('package.deps').decode('utf-8-sig'))
    assert not deps['modDependencies'] and not deps['dlcDependencies']

short = 'The original Buckingham Fountain model, classified as a placeable building, with ornate tiers, bronze-colored sculptures and fixed nighttime lighting.'
long = '''GPT's Buckingham Fountain, by X_Bean_X.

The original Chicago GPT fountain model, now classified as a building. Its ornate tiered stonework, lobed basin, bronze-colored sea-horse sculptures, original water geometry and existing warm/violet lighting are retained.

Features
- Placeable building classification with an 11 x 11-cell footprint.
- Original approximately 85.344-metre basin width and three mesh detail levels.
- All 56 original native lighting entries retained.
- No companion code mod required by the package.

This is the original version. It does not include the particle spray show, two-minute color cycle, taller tiers or perimeter railing lamps from GPT's Buckingham Fountain, Animated. Pavers are not included.

Cover: illustrated promotional artwork based on the original model. Included reference screenshots show the original model before this classification change. Fresh building-placement and reload screenshots will replace them after the pending in-game validation.
'''
(outdir / 'ShortDescription.txt').write_text(short, encoding='utf-8')
(outdir / 'Description.txt').write_text(long, encoding='utf-8')
(outdir / 'README.txt').write_text('STAGED ONLY - DO NOT UPLOAD YET\n' + NAME + '\nCreator: X_Bean_X\nNative building-classified candidate; in-game placement, lighting, and save/reload checks pending.\nThe installed original package and current map have not been changed.\nPublishing remains on hold at the user request.\n', encoding='utf-8')
screens = outdir / 'Screenshots'; screens.mkdir()
for period in ['day', 'night']:
    shutil.copy2(R / 'Outputs/Previews' / ('CS2_' + period + '_reloaded.jpg'), screens / ('original-model-' + period + '-before-classification.jpg'))
cover = Path('C:/Users/YOUR_USER/.codex/generated_images/01a166b1-0e82-7d90-ae08-760c448c0850/exec-8d6cfcb4-4a08-4929-bdf4-86b484ad80ec.png')
shutil.copy2(cover, outdir / 'Preview.png')
report = {'name': NAME, 'author': 'X_Bean_X', 'version': '1.0.0',
          'classificationBefore': 'StaticObjectPrefab', 'classificationAfter': 'BuildingPrefab',
          'rootCID': '90a3b77f8fbdf731a8d9e556f7b85d7a', 'rootIdentityPreserved': True,
          'lotCells': [11, 11], 'originalEffectsPreserved': 56, 'meshesAndMaterialsUnchanged': True,
          'changedArchiveEntries': changed, 'crcPassed': True, 'dependencies': deps,
          'package': str(out), 'sha256': sha(out), 'sourceSHA256': EXPECTED,
          'installedSourceUnchanged': sha(SOURCE) == EXPECTED, 'inGameValidation': 'pending',
          'publicationOnHold': True, 'published': False,
          'pendingChecks': ['Native load and building classification', 'Placeable footprint and visual fit',
                            'Day/night lighting on building instances', 'Separate save and fresh reload',
                            'Old prop save compatibility; do not claim automatic migration until tested'],
          'coverMethod': 'Built-in image generation; original model reference and navy/gold style reference'}
(outdir / 'release.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
(R / 'Docs/BUILDING_CLASSIFICATION_V2.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
