from pathlib import Path
import zipfile,json,hashlib,uuid
r=Path(__file__).resolve().parents[1];src=r/"Release/BuildingV3/GPT's Buckingham Fountain.cok"
assert hashlib.sha256(src.read_bytes()).hexdigest()=='dea0e28967c256211f0a5eb4e3765537e0cb0259763d62c41bb2adac492a71f3'
out=r/'Release/BuildingV4';out.mkdir(exist_ok=False)
with zipfile.ZipFile(src) as z:entries={n:z.read(n) for n in z.namelist()}
for n in ('ACMBuckinghamWarmLightBuildingV3.Prefab','ACMBuckinghamVioletLightBuildingV3.Prefab'):
 s=entries[n];assert s.count(b'"m_DisableDistanceCulling": false')==1
 entries[n]=s.replace(b'"m_DisableDistanceCulling": false',b'"m_DisableDistanceCulling": true')
entries['package.deps.cid']=uuid.uuid4().hex.encode()
target=out/src.name
with zipfile.ZipFile(target,'w',zipfile.ZIP_STORED) as z:
 for n,b in entries.items():z.writestr(n,b)
with zipfile.ZipFile(target) as z:assert z.testzip() is None
report=json.loads((r/'Release/BuildingV3/release.json').read_text());report.update(package=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),revision=4,lightCulling='Native owner-based culling, matching the verified animated controller',validation='runtime test: all 56 lights enabled and visible; final package restart/day/night pending')
(out/'release.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
