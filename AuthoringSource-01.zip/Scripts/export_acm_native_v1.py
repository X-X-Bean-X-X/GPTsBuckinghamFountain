"""Repair native CS2 FBX units/axes without rebuilding geometry or rebaking textures.
Reads v003, stages six FBXs, validates raw FBX coordinates at CS2's 0.01 scale.
Does not replace imported files; promotion follows successful validation.
"""
from pathlib import Path
import bpy, bmesh, json, math
import numpy as np
from io_scene_fbx import parse_fbx

root = Path(r"H:\Games\GPT, Chicago AI Project\ACM - Buildings\Buckingham Fountain")
stage = root / "Assets" / "Import" / "ACMBuckinghamFountainV1"
stage.mkdir(parents=True, exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root / "Working" / "Buckingham_Fountain_v003.blend"))
scene = bpy.context.scene
export_col = bpy.data.collections["80 Game export meshes"]
export_col.hide_viewport = False
export_col.hide_render = False
sources = [(bpy.data.objects["BuckinghamFountain"], False),
           (bpy.data.objects["BuckinghamFountain_Wat"], True)]
for obj, _ in sources:
    obj.hide_set(False)
    obj.hide_viewport = False
    obj.name = "REPAIR_SOURCE_" + obj.name

def active(obj):
    bpy.ops.object.select_all(action="DESELECT")
    obj.hide_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

def raw_bounds(path):
    tree, version = parse_fbx.parse(str(path))
    objects = next(e for e in tree.elems if e.id == b"Objects")
    arrays = []
    for geom in objects.elems:
        if geom.id == b"Geometry":
            for e in geom.elems:
                if e.id == b"Vertices":
                    arrays.append(np.asarray(e.props[0], dtype=np.float64).reshape(-1,3))
    assert arrays, "No vertices in FBX"
    points = np.concatenate(arrays) * 0.01
    return points.min(axis=0), points.max(axis=0)

results = []
for source, is_water in sources:
    for lod, ratio in [(0,1.0),(1,0.30),(2,0.07)]:
        name = "ACMBuckinghamFountainV1" + (f"_LOD{lod}" if lod else "") + ("_Wat" if is_water else "")
        obj = source.copy()
        obj.data = source.data.copy()
        export_col.objects.link(obj)
        obj.name = obj.data.name = name
        active(obj)
        if lod and not is_water:
            mod = obj.modifiers.new("Distance simplification", "DECIMATE")
            mod.ratio = ratio
            bpy.ops.object.modifier_apply(modifier=mod.name)
        path = stage / (name + ".fbx")
        bpy.ops.export_scene.fbx(filepath=str(path), use_selection=True, object_types={"MESH"},
            global_scale=1.0, apply_unit_scale=True, apply_scale_options="FBX_SCALE_NONE",
            axis_forward="-Z", axis_up="Y", bake_space_transform=True,
            use_mesh_modifiers=True, mesh_smooth_type="FACE", use_tspace=True,
            add_leaf_bones=False, bake_anim=False, path_mode="AUTO")
        low, high = raw_bounds(path)
        size = high - low
        assert 80 < size[0] < 87 and 80 < size[2] < 87, (name, size)
        assert 7 < size[1] < 9, (name, size)
        assert -1 < low[1] < 1 and 7 < high[1] < 9, (name, low, high)
        record = {"name":name, "file":str(path), "triangles":len(obj.data.polygons),
                  "native_import_scale":0.01, "min_m":low.tolist(),
                  "max_m":high.tolist(), "size_m":size.tolist()}
        results.append(record)
        print("RAW_FBX_PASS " + json.dumps(record), flush=True)
        mesh = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.meshes.remove(mesh)
(root / "Docs" / "acm_v1_raw_export_validation.json").write_text(
    json.dumps({"status":"raw FBX coordinates validated; CS2 reimport pending",
                "export_settings":{"bake_space_transform":True,"apply_scale_options":"FBX_SCALE_NONE",
                                   "axis_forward":"-Z","axis_up":"Y"},
                "models":results}, indent=2), encoding="utf-8")
print("EXPORT_FIX_STAGE_PASS", flush=True)

import shutil
source_textures=root/"Assets"/"Import"/"BuckinghamFountain"
for src in source_textures.glob("*.png"):
    target=stage/src.name.replace("BuckinghamFountain","ACMBuckinghamFountainV1",1)
    shutil.copy2(src,target)
print("FRESH_IMPORT_READY_21_FILES",flush=True)
