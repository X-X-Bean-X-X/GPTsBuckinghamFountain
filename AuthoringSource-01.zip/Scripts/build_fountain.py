"""Buckingham Fountain, editable modelling checkpoint. Blender 5.2.

Run in a separate Blender process: blender --background --factory-startup
 --python build_fountain.py -- --root PROJECT_ROOT
Physical diameters: Chicago Park District. Ornamental profiles are photo estimates.
This source scene is not itself a tested CS2 prefab.
"""
import argparse
import json
import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

parser = argparse.ArgumentParser()
parser.add_argument('--root', default=str(Path(__file__).resolve().parents[1]))
parser.add_argument('--render', action='store_true')
args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else [])
ROOT = Path(args.root)
for sub in ['Assets', 'Outputs/Previews', 'Working', 'Docs']:
    (ROOT / sub).mkdir(parents=True, exist_ok=True)
random.seed(27)
TAU = 2 * math.pi
R_POOL, R_LOWER, R_MIDDLE, R_TOP = 42.672, 15.6972, 9.144, 3.6576
WATER_Z = 0.25
TOP_Z = WATER_Z + 7.62
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 1
scene.render.engine = 'CYCLES'
scene.cycles.samples = 48
scene.cycles.use_denoising = True
scene.render.resolution_x, scene.render.resolution_y = 1600, 1100
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.world = bpy.data.worlds.new('Studio sky')
scene.world.use_nodes = True
scene.world.node_tree.nodes['Background'].inputs[0].default_value = (0.65, 0.75, 0.88, 1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value = 0.4
scene.view_settings.view_transform = 'AgX'
COLS = {}
for name in ['01 Basin', '02 Architecture', '03 Carved ornament', '04 Bronze sculptures',
             '05 Water surfaces', '06 Lighting guides', '90 Presentation']:
    col = bpy.data.collections.new(name)
    scene.collection.children.link(col)
    COLS[name] = col


def material(name, color, roughness, metallic=0, noise_scale=3, variation=0.1):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1)
    mat.use_nodes = True
    n, links = mat.node_tree.nodes, mat.node_tree.links
    bs = n.get('Principled BSDF')
    bs.inputs['Base Color'].default_value = (*color, 1)
    bs.inputs['Roughness'].default_value = roughness
    bs.inputs['Metallic'].default_value = metallic
    tex = n.new('ShaderNodeTexNoise')
    tex.inputs['Scale'].default_value = noise_scale
    tex.inputs['Detail'].default_value = 4
    tex.inputs['Roughness'].default_value = 0.75
    coord = n.new('ShaderNodeTexCoord')
    links.new(coord.outputs['Object'], tex.inputs['Vector'])
    ramp = n.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.2
    ramp.color_ramp.elements[0].color = (*(max(0, c * (1 - variation)) for c in color), 1)
    ramp.color_ramp.elements[1].position = 0.8
    ramp.color_ramp.elements[1].color = (*(min(1, c * (1 + variation)) for c in color), 1)
    links.new(tex.outputs['Fac'], ramp.inputs[0])
    links.new(ramp.outputs[0], bs.inputs['Base Color'])
    bump = n.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.16
    bump.inputs['Distance'].default_value = 0.018 if metallic == 0 else 0.008
    links.new(tex.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs[0], bs.inputs['Normal'])
    return mat


STONE = material('Georgia pink marble', (0.48, 0.365, 0.275), 0.57, noise_scale=3, variation=0.20)
LIP = material('Pale worn marble coping', (0.64, 0.53, 0.405), 0.44, noise_scale=6, variation=0.13)
BASE = material('Rose granite foundation', (0.245, 0.14, 0.115), 0.71, noise_scale=12, variation=0.18)
BRONZE = material('Aged bronze verdigris', (0.105, 0.255, 0.205), 0.55, 0.55, 4, 0.5)
DARK = material('Bronze recesses', (0.032, 0.06, 0.048), 0.5, 0.55)
POOL = material('Basin lining', (0.13, 0.205, 0.185), 0.7, noise_scale=4, variation=0.12)
WATER = material('Still water - preview material', (0.04, 0.17, 0.155), 0.19, 0.18, 2.2, 0.08)
water_bs = WATER.node_tree.nodes.get('Principled BSDF')
water_bs.inputs['Transmission Weight'].default_value = 0.18
water_bs.inputs['IOR'].default_value = 1.333
GROUND = material('Presentation ground - excluded from export', (0.20, 0.225, 0.21), 0.9)


def object_from_mesh(name, verts, faces, mat, collection='02 Architecture', smooth=False):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    COLS[collection].objects.link(obj)
    mesh.materials.append(mat)
    for polygon in mesh.polygons:
        polygon.use_smooth = smooth
    return obj


def lathe(name, profile, mat, count=192, center=(0, 0, 0), collection='02 Architecture'):
    verts, faces = [], []
    for r, z in profile:
        verts.extend([(center[0] + r * math.cos(i * TAU / count),
                       center[1] + r * math.sin(i * TAU / count), center[2] + z) for i in range(count)])
    for j in range(len(profile) - 1):
        for i in range(count):
            a, b = j * count + i, j * count + (i + 1) % count
            faces.append((a, b, b + count, a + count))
    if collection == '05 Water surfaces':
        faces = [tuple(reversed(face)) for face in faces]
    return object_from_mesh(name, verts, faces, mat, collection, True)


def radial(r, angle, z=0):
    return (r * math.cos(angle), r * math.sin(angle), z)


def sphere(name, pos, size, mat, collection='03 Carved ornament', segments=16, rings=10):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, location=pos)
    obj = bpy.context.object
    obj.name = name
    obj.scale = size
    for col in list(obj.users_collection):
        col.objects.unlink(obj)
    COLS[collection].objects.link(obj)
    obj.data.materials.append(mat)
    for p in obj.data.polygons:
        p.use_smooth = True
    return obj


def tube(name, points, radii, mat, sides=8, collection='03 Carved ornament'):
    verts, faces = [], []
    for i, point in enumerate(points):
        p = Vector(point)
        tangent = Vector(points[min(i + 1, len(points) - 1)]) - Vector(points[max(i - 1, 0)])
        tangent.normalize()
        axis = tangent.cross(Vector((0, 0, 1)))
        if axis.length < 0.01:
            axis = tangent.cross(Vector((0, 1, 0)))
        axis.normalize()
        other = tangent.cross(axis).normalized()
        rad = radii[i] if isinstance(radii, list) else radii
        if isinstance(rad, tuple):
            ra, rb = rad
        else:
            ra = rb = rad
        verts.extend([tuple(p + ra * math.cos(a * TAU / sides) * axis + rb * math.sin(a * TAU / sides) * other) for a in range(sides)])
    for j in range(len(points) - 1):
        for i in range(sides):
            a, b = j * sides + i, j * sides + (i + 1) % sides
            faces.append((a, b, b + sides, a + sides))
    faces.append(tuple(range(sides - 1, -1, -1)))
    faces.append(tuple((len(points) - 1) * sides + i for i in range(sides)))
    return object_from_mesh(name, verts, faces, mat, collection, True)


def catmull(points, samples=5):
    p = [Vector(points[0]), *map(Vector, points), Vector(points[-1])]
    out = []
    for i in range(1, len(p) - 2):
        a, b, c, d = p[i-1:i+3]
        for k in range(samples):
            t = k / samples
            out.append(tuple(0.5 * ((2*b) + (-a+c)*t + (2*a-5*b+4*c-d)*t*t + (-a+3*b-3*c+d)*t*t*t)))
    out.append(tuple(points[-1]))
    return out


def leaf(name, origin, width, height, lean, angle, mat=BRONZE, collection='04 Bronze sculptures'):
    verts, faces = [], []
    for j in range(9):
        t = j / 8
        w = width * (math.sin(math.pi*t) ** 0.68) + 0.015
        for k in range(5):
            u = (k - 2) / 2
            x, y, z = w*u, lean*t*t + 0.15*width*(1-u*u)*math.sin(math.pi*t), height*t
            verts.append((origin[0]+x*math.cos(angle)-y*math.sin(angle), origin[1]+x*math.sin(angle)+y*math.cos(angle), origin[2]+z))
    for j in range(8):
        for k in range(4):
            a = j*5+k
            faces.extend([(a,a+1,a+6,a+5),(a+5,a+6,a+1,a)])
    return object_from_mesh(name, verts, faces, mat, collection, True)


# Mapped basin outline, smoothed along the four lobes; corners kept sharp.
source_outline = json.loads((ROOT/'Assets'/'pool_outline.json').read_text())
raw = source_outline['points_metres']
pts = []
for first in [1,15,29,43]:
    arc = raw[first:first+13]
    smooth = catmull([(x,y,0) for x,y in arc],6)
    pts.extend([(x,y) for x,y,z in smooth])
    pts.append(raw[(first+13)%56])
pts.reverse()
span_x=max(x for x,y in pts)-min(x for x,y in pts)
span_y=max(y for x,y in pts)-min(y for x,y in pts)
pts=[(x*85.344/span_x,y*85.344/span_y) for x,y in pts]
N=len(pts)
def offset_point(x,y,d,z):
    r=math.hypot(x,y)
    return (x*(r+d)/r,y*(r+d)/r,z)
verts,faces=[],[]
rim_profile=[(0,-0.42),(0,0.43),(-0.12,0.59),(-0.60,0.61),(-0.82,0.52),(-0.84,-0.32),(0,-0.42)]
for dr,z in rim_profile:
    verts.extend([offset_point(x,y,dr,z) for x,y in pts])
for j in range(len(rim_profile)-1):
    for i in range(N):
        a,b=j*N+i,j*N+(i+1)%N
        faces.append((a,b,b+N,a+N))
object_from_mesh('Mapped outer basin coping - 85.344 m',verts,faces,LIP,'01 Basin',True)
for label,z,mat in [('Basin floor',-0.34,POOL),('Outer pool water',WATER_Z,WATER)]:
    v=[(0,0,z)]+[offset_point(x,y,-0.81,z) for x,y in pts]
    f=[(0,i+1,(i+1)%N+1) for i in range(N)]
    object_from_mesh(label,v,f,mat,'05 Water surfaces' if 'water' in label else '01 Basin')


def basin(name, r, bottom, top, panels):
    h=top-bottom
    lathe(name+' granite plinth',[(0,bottom-0.05),(r-0.20,bottom-0.05),(r-0.12,bottom+0.16),(r-0.3,bottom+0.29),(0,bottom+0.29)],BASE)
    profile=[(r-0.65,bottom+0.25),(r-0.40,bottom+0.34),(r-0.70,bottom+0.49),
             (r-1.1,bottom+0.65),(r-0.75,top-0.72),(r-0.42,top-0.31),
             (r-0.10,top-0.23),(r,top-0.13),(r,top-0.035),
             (r-0.04,top),(r-0.43,top),(r-0.60,top-0.22),
             (r-0.78,bottom+0.52),(0,bottom+0.52)]
    lathe(name+' carved marble bowl',profile,STONE)
    lathe(name+' rounded lip',[(r-0.35,top-0.13),(r,top-0.13),(r+0.018,top-0.07),(r-0.03,top),(r-0.37,top),(r-0.35,top-0.13)],LIP)
    lathe(name+' still water',[(0,top-0.16),(r-0.5,top-0.16)],WATER,collection='05 Water surfaces')
    for i in range(panels):
        a=i*TAU/panels
        # Vertical raised shell/floral relief with a dark bronze spout.
        pos=radial(r-0.72,a,bottom+0.65)
        for k in range(5):
            leaf(name+f' relief {i:02d}.{k}',pos,0.16,0.70+0.18*math.sin(k*math.pi/4),0.17,a+k*0.18-0.36,STONE,'03 Carved ornament')
        obj=sphere(name+f' spout mask {i:02d}',radial(r-0.42,a,bottom+0.73),(0.24,0.16,0.25),BRONZE)
        obj.rotation_euler[2]=a-math.pi/2
        sphere(name+f' spout opening {i:02d}',radial(r-0.24,a,bottom+0.66),(0.075,0.075,0.064),DARK)
        # Panel boundary bead, following the concave bowl profile.
        aa=a+TAU/panels/2
        tube(name+f' panel bead {i:02d}',[radial(r-0.43,aa,top-0.27),radial(r-0.60,aa,top-0.65),radial(r-0.83,aa,bottom+0.75)],0.029,LIP,6)


basin('Lower 103 ft basin',R_LOWER,0.35,2.57,36)
basin('Middle 60 ft basin',R_MIDDLE,2.42,4.84,24)
lathe('Upper pedestal base',[(0,4.56),(2.85,4.56),(2.9,4.8),(2.62,4.97),(2.47,5.12),(0,5.12)],BASE)
lathe('Upper fluted drum',[(0,4.99),(1.83,4.99),(1.74,5.20),(1.57,5.55),(1.63,6.57),(1.89,6.72),(0,6.72)],STONE)
for i in range(48):
    a=i*TAU/48
    tube(f'Drum flute {i:02d}',[radial(1.77,a,5.13),radial(1.59,a,5.61),radial(1.66,a,6.44),radial(1.83,a,6.70)],0.068,LIP,8)
lathe('Upper 24 ft bowl',[(1.73,6.54),(2.43,6.59),(2.83,6.76),(3.11,6.99),(3.40,7.28),(3.54,7.61),(R_TOP,7.70),(R_TOP,TOP_Z),(R_TOP-0.25,TOP_Z),(3.28,7.59),(2.89,7.27),(0,7.18)],STONE)
lathe('Upper bowl rounded lip',[(R_TOP-0.30,7.70),(R_TOP,7.70),(R_TOP,TOP_Z),(R_TOP-0.30,TOP_Z),(R_TOP-0.30,7.70)],LIP)
lathe('Upper bowl still water',[(0,TOP_Z-0.15),(R_TOP-0.3,TOP_Z-0.15)],WATER,collection='05 Water surfaces')


def console(name,r,angle,z,height,width):
    # Swept, tapering masonry console, with paired scrolls and leaf relief.
    p=[(0,0),(0.15,0.10),(0.21,0.27),(0.13,0.42),(0.0,0.72),(-0.03,0.92),(0.12,1.0)]
    v=[]
    for depth,t in p:
        w=width*(0.72+0.28*abs(2*t-1))
        for side in [-1,1]:
            v.append((math.cos(angle)*(r+depth*height)-math.sin(angle)*side*w,
                      math.sin(angle)*(r+depth*height)+math.cos(angle)*side*w,z+t*height))
    f=[]
    for i in range(len(p)-1):f.append((2*i,2*i+1,2*i+3,2*i+2))
    f.extend([tuple(range(0,len(v),2)),tuple(range(len(v)-1,0,-2))])
    object_from_mesh(name,v,f,STONE,'03 Carved ornament',True)
    lathe(name+' capital',[(0,0),(width*1.19,0),(width*1.28,0.1),(width*1.18,0.18),(0,0.18)],LIP,24,radial(r+0.12*height,angle,z+height))
    for sign in [-1,1]:
        pts=[]
        for i in range(22):
            t=i/21*math.pi*1.8
            s=height*0.18*(1-i/24)
            d=0.05*height+s*math.cos(t)
            h=height*0.24+s*math.sin(t)
            pts.append((math.cos(angle)*(r+d)-math.sin(angle)*sign*width*0.8,
                        math.sin(angle)*(r+d)+math.cos(angle)*sign*width*0.8,z+h))
        tube(name+' volute',pts,height*0.028,LIP,8)


for label,r,z,h,w,n in [('Lower',15.26,0.46,2.34,0.38,12),('Middle',8.68,2.69,2.44,0.35,12)]:
    for i in range(n):console(f'{label} scroll console {i+1:02d}',r,i*TAU/n,z,h,w)
for i in range(10):
    a=i*TAU/10
    lathe(f'Upper support column {i+1:02d}',[(0,0),(0.22,0),(0.23,0.13),(0.145,0.25),(0.12,1.38),(0.22,1.47),(0.26,1.60),(0,1.60)],BASE,20,radial(2.48,a,5.09))
    console(f'Upper capital scroll {i+1:02d}',2.48,a,6.49,0.48,0.22)


# Sculptures are editable photo-based approximations, not scans of the originals.
def sea_horse(group, side, angle):
    def transform(p):
        x,y,z=p
        x=side*x
        return (math.cos(angle)*(26.1+y)-math.sin(angle)*x,
                math.sin(angle)*(26.1+y)+math.cos(angle)*x,WATER_Z+z)
    tag=f'Sea horse {group+1}.{1 if side<0 else 2}'
    controls=[(0.20,-0.95,0.34),(1.1,-0.8,0.4),(2.3,-0.5,0.65),(3.0,0.0,1.02),(3.1,0.35,1.65),(2.8,0.52,2.28),(2.72,0.65,2.92),(3.03,0.85,3.35),(3.39,1.18,3.25)]
    pts=catmull(controls,4)
    rs=[]
    key=[0.12,0.25,0.47,0.7,0.73,0.60,0.42,0.37,0.24]
    for i in range(len(pts)):
        q=i/(len(pts)-1)*(len(key)-1);j=min(int(q),len(key)-2);r=key[j]*(1-(q-j))+key[j+1]*(q-j)
        rs.append((r,r*0.90))
    tube(tag+' body and neck',[transform(p) for p in pts],rs,BRONZE,14,'04 Bronze sculptures')
    snout=catmull([(3.02,0.89,3.31),(3.31,1.15,3.29),(3.58,1.40,3.12),(3.77,1.49,3.10)],5)
    tube(tag+' muzzle',[transform(p) for p in snout],[0.23-i*0.005 for i in range(len(snout))],BRONZE,12,'04 Bronze sculptures')
    for eye_side in [-1,1]:
        sphere(tag+' eye',transform((3.12+eye_side*0.17,1.13,3.39)),(0.07,0.075,0.07),DARK,'04 Bronze sculptures',12,8)
    for x in [2.82,3.10]:
        tube(tag+' ear',[transform((x,0.77,3.41)),transform((x-0.12,0.66,3.91)),transform((x+0.06,0.72,3.82))],[0.13,0.055,0.015],BRONZE,8,'04 Bronze sculptures')
    for leg in [-1,1]:
        c=[(3.0,0.34+leg*0.38,1.82),(3.52,0.49+leg*0.52,1.53),(3.74,1.0+leg*0.43,1.82),(3.98,1.10+leg*0.40,1.54)]
        ps=catmull(c,5)
        tube(tag+' raised foreleg',[transform(p) for p in ps],[0.20-i*0.008 for i in range(len(ps))],BRONZE,10,'04 Bronze sculptures')
    # Flowing mane fins and fish-tail lobes make the hybrid silhouette readable.
    for k in range(10):
        t=k/9
        p=(2.64+0.30*math.sin(t*math.pi),0.03,1.35+1.95*t)
        leaf(tag+f' mane fin {k}',transform(p),0.21,0.60,0.2,angle+side*0.7,BRONZE)
    for k in range(7):
        leaf(tag+f' tail fan {k}',transform((0.48,-0.91,0.23)),0.35,1.1+0.35*math.sin(k*math.pi/6),0.8,angle+math.pi/2+(k-3)*0.22,BRONZE)


for g in range(4):
    a=math.pi/4+g*math.pi/2
    lathe(f'Bronze sculpture island {g+1}',[(0,-0.06),(4.6,-0.06),(4.6,0.12),(0,0.12)],BRONZE,64,radial(26.1,a,WATER_Z-0.16),'04 Bronze sculptures')
    for side in [-1,1]:sea_horse(g,side,a)
    for k in range(15):
        leaf(f'Sea horse group {g+1} rush {k}',radial(25.5+random.uniform(-0.65,0.65),a+random.uniform(-0.022,0.022),WATER_Z+0.1),0.31,random.uniform(1.1,2.25),random.uniform(-0.3,0.7),a+k*0.48)
for g in range(4):
    a=g*math.pi/2
    center=radial(24.2,a,WATER_Z)
    lathe(f'Bulrush crown {g+1}',[(0,-0.02),(1.03,-0.02),(1.2,0.4),(1.30,0.9),(1.0,0.86),(0.89,0.4),(0,0.1)],BRONZE,48,center,'04 Bronze sculptures')
    for k in range(16):
        b=k*TAU/16
        pos=(center[0]+math.cos(b),center[1]+math.sin(b),center[2]+0.25)
        leaf(f'Bulrush crown {g+1} blade {k}',pos,0.16,1.20+0.25*math.sin(k*2),0.34,b)


# Fixture housings and named guide empties for the game's night-light setup.
lighting=[]
for ring,r,z,n in [('lower',14.5,0.65,24),('middle',8.10,2.83,16),('upper',2.35,5.1,8),('pool',25.0,0.34,8)]:
    for i in range(n):
        a=i*TAU/n
        pos=radial(r,a,z)
        sphere(f'{ring} lamp housing {i:02d}',pos,(0.15,0.15,0.10),DARK,'06 Lighting guides',12,8)
        empty=bpy.data.objects.new(f'CS2 light guide {ring} {i:02d}',None)
        empty.location=pos;empty.empty_display_size=0.28
        empty['purpose']='Position guide only. Requires native CS2 light/effect configuration.'
        COLS['06 Lighting guides'].objects.link(empty)
        lighting.append({'ring':ring,'position_blender_m':list(pos),'color':'violet' if i%3 else 'warm_white'})


def aim(obj,point):
    obj.rotation_euler=(Vector(point)-obj.location).to_track_quat('-Z','Y').to_euler()


def camera(name,pos,target,lens=48):
    data=bpy.data.cameras.new(name);obj=bpy.data.objects.new(name,data)
    COLS['90 Presentation'].objects.link(obj);obj.location=pos;data.lens=lens
    data.clip_end=2000;aim(obj,target);return obj


hero=camera('Camera overall',(77,-98,65),(0,0,1.7),48)
detail=camera('Camera architectural detail',(36,-46,22),(0,0,3.5),55)
front=camera('Camera elevation',(0,-65,7.5),(0,0,3.7),50)
scene.camera=hero
sun_data=bpy.data.lights.new('Day sun','SUN');sun_data.energy=2.6;sun_data.angle=0.17
sun=bpy.data.objects.new('Day sun',sun_data);COLS['90 Presentation'].objects.link(sun)
sun.rotation_euler=(math.radians(30),math.radians(-22),math.radians(-35))
object_from_mesh('Presentation ground',[(-180,-180,-0.46),(180,-180,-0.46),(180,180,-0.46),(-180,180,-0.46)],[(0,1,2,3)],GROUND,'90 Presentation')
for obj in bpy.context.selected_objects:obj.select_set(False)
for area in (bpy.context.screen.areas if bpy.context.screen else []):
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_distance=92
        area.spaces.active.region_3d.view_location=(0,0,2)
        area.spaces.active.clip_end=2000
scene['asset_status']='Editable geometry checkpoint; game import and map scale pending'
scene['scale_basis']='1 Blender unit = 1 metre; basin diameters from Chicago Park District'
scene['height_note']='7.62 m above outer-pool water used provisionally; source water datum ambiguous'
scene['reference_source']='https://www.chicagoparkdistrict.com/parks-facilities/clarence-f-buckingham-memorial-fountain'
scene['ornament_note']='Carvings, sculpture shapes, and console counts inferred from photos; pool outline from OSM, scaled to published diameter'
scene['night_status']='Fixture guides only; actual native game lights still to configure'
asset_objects=[o for c in COLS.values() if c.name!='90 Presentation' for o in c.objects if o.type=='MESH']
stats={'blender_version':bpy.app.version_string,'mesh_objects':len(asset_objects),'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in asset_objects),'dimensions_m':{'outer_pool_nominal_diameter':R_POOL*2,'lower_basin':R_LOWER*2,'middle_basin':R_MIDDLE*2,'upper_basin':R_TOP*2},'status':scene['asset_status'],'limitations':[scene['height_note'],scene['ornament_note'],scene['night_status']]}
(ROOT/'Docs'/'geometry_checkpoint.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
(ROOT/'Docs'/'lighting_guides.json').write_text(json.dumps(lighting,indent=2),encoding='utf-8')
readme=bpy.data.texts.new('START HERE - modelling checkpoint')
readme.write(json.dumps(stats,indent=2))
blend=ROOT/'Working'/'Buckingham_Fountain_v002.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(blend))
print('BF_CHECKPOINT_SAVED '+str(blend),flush=True)
print(json.dumps(stats),flush=True)
if args.render:
    try:
        prefs=bpy.context.preferences.addons['cycles'].preferences
        prefs.compute_device_type='OPTIX';prefs.get_devices()
        for dev in prefs.devices:dev.use=dev.type=='OPTIX'
        if any(d.type=='OPTIX' for d in prefs.devices):scene.cycles.device='GPU'
    except Exception as e:print('GPU setup: '+str(e),flush=True)
    for cam,name in [(hero,'01_overall_day'),(detail,'02_architecture_day'),(front,'03_elevation_day')]:
        scene.camera=cam;scene.render.filepath=str(ROOT/'Outputs'/'Previews'/(name+'.png'))
        bpy.ops.render.render(write_still=True)
        print('BF_RENDER_SAVED '+name,flush=True)
