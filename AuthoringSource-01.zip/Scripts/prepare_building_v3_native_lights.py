from pathlib import Path
import json,re,copy,zipfile,uuid,hashlib
r=Path(__file__).resolve().parents[1]
src=r/"Release/BuildingV2/GPT's Buckingham Fountain.cok"
assert hashlib.sha256(src.read_bytes()).hexdigest()=='2b603dce499059401fbbaba1eb39bd64b97fd7f70da9e2be8f842c6a3161b589'
out=r/'Release/BuildingV3';out.mkdir(exist_ok=True)
assert not (out/src.name).exists()
rootfile='ACMBuckinghamFountainV1_7af8431e49336acc76bdf3386b66a6c5.Prefab'
def decode(data):
 d=json.loads(re.sub(r'\$fstrref:"([^"]+)"',r'"ASSETREF:\1"',data.decode('utf-8-sig')))
 types={}
 def collect(x):
  if isinstance(x,dict):
   assert '$ref' not in x
   if isinstance(x.get('$type'),str):
    n,t=x['$type'].split('|',1);types[int(n)]=t
   for v in x.values():collect(v)
  elif isinstance(x,list):
   for v in x:collect(v)
 collect(d)
 def expand(x):
  if isinstance(x,dict):
   if '$type' in x:x['$type']=types[int(str(x['$type']).split('|')[0])]
   for v in x.values():expand(v)
  elif isinstance(x,list):
   for v in x:expand(v)
 expand(d);return d
def encode(d):
 d=copy.deepcopy(d);types={};ids=[0]
 def convert(x):
  if isinstance(x,dict):
   if '$id' in x:x['$id']=ids[0];ids[0]+=1
   if '$type' in x:
    t=x['$type']
    if t not in types:types[t]=len(types);x['$type']=str(types[t])+'|'+t
    else:x['$type']=types[t]
   for v in x.values():convert(v)
  elif isinstance(x,list):
   for v in x:convert(v)
 convert(d)
 return re.sub(r'"ASSETREF:([^"]+)"',r'$fstrref:"\1"',json.dumps(d,indent=4)).encode()
with zipfile.ZipFile(src) as z:entries={n:z.read(n) for n in z.namelist()}
root=decode(entries[rootfile]);old=copy.deepcopy(root)
fx=root['components']['$rcontent'].pop(0)
assert fx['name']=='EffectSource' and len(fx['m_Effects']['$rcontent'])==56
lightmap={}
for n in ['ACMBuckinghamWarmLightV1.Prefab','ACMBuckinghamVioletLightV1.Prefab']:
 text=entries[n].decode('utf-8-sig');oldcid=entries[n+'.cid'].decode().strip();newcid=uuid.uuid4().hex
 assert '"m_RequiredFlags": 8192' in text and '"m_ForbiddenFlags": 32768' in text
 newfile=n.replace('V1','BuildingV3');text=text.replace(n[:-7],newfile[:-7]).replace('"m_RequiredFlags": 8192','"m_RequiredFlags": 0')
 entries[newfile]=text.encode();entries[newfile+'.cid']=newcid.encode();lightmap[oldcid]=newcid
for e in fx['m_Effects']['$rcontent']:
 oldcid=e['m_Effect'].split(':')[-1];e['m_Effect']='ASSETREF:CID:'+lightmap[oldcid]
childcid=uuid.uuid4().hex
child={'$id':0,'$type':'Game.Prefabs.StaticObjectPrefab, Game','name':'ACMBuckinghamNativeLightControllerV3','active':True,'version':1,'m_prefabFormat':0,'components':{'$id':1,'$type':'System.Collections.Generic.List`1[[Game.Prefabs.ComponentBase, Game]], mscorlib','$rlength':2,'$rcontent':[fx,{'$id':2,'$type':'Game.Prefabs.StreetLightObject, Game','name':'StreetLightObject','active':True,'m_Layer':0}]},'m_Meshes':{'$id':3,'$type':'Game.Prefabs.ObjectMeshInfo[], Game','$rlength':0,'$rcontent':[]},'m_Circular':False}
v={'$type':'Unity.Mathematics.float3, Unity.Mathematics','x':0,'y':0,'z':0}
rot={'$type':'Unity.Mathematics.quaternion, Unity.Mathematics','value':{'$type':'Unity.Mathematics.float4, Unity.Mathematics','x':0,'y':0,'z':0,'w':1}}
root['components']['$rcontent'].append({'$id':90,'$type':'Game.Prefabs.ObjectSubObjects, Game','name':'ObjectSubObjects','active':True,'m_SubObjects':{'$id':91,'$type':'Game.Prefabs.ObjectSubObjectInfo[], Game','$rlength':1,'$rcontent':[{'$id':92,'$type':'Game.Prefabs.ObjectSubObjectInfo, Game','m_Object':'ASSETREF:CID:'+childcid,'m_Position':v,'m_Rotation':rot,'m_ParentMesh':0,'m_GroupIndex':0,'m_Probability':100}]}})
root['components']['$rlength']=len(root['components']['$rcontent'])
assert root['m_Meshes']==old['m_Meshes']
entries[rootfile]=encode(root)
entries[child['name']+'.Prefab']=encode(child);entries[child['name']+'.Prefab.cid']=childcid.encode()
entries['package.deps.cid']=uuid.uuid4().hex.encode()
target=out/src.name
with zipfile.ZipFile(target,'w',zipfile.ZIP_STORED) as z:
 for n,b in entries.items():z.writestr(n,b)
with zipfile.ZipFile(target) as z,zipfile.ZipFile(src) as oldz:
 assert z.testzip() is None
 changed=[n for n in oldz.namelist() if oldz.read(n)!=z.read(n)]
 assert set(changed)=={rootfile,'package.deps.cid'}
 decode(z.read(rootfile));decode(z.read(child['name']+'.Prefab'))
report={'name':root['name'],'package':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'rootCID':entries[rootfile+'.cid'].decode(),'lightControllerCID':childcid,'changedExistingEntries':changed,'addedEntries':[n for n in entries if n not in oldz.namelist()],'geometryMaterialsTexturesByteUnchanged':True,'lightPlacementAndAppearancePreserved':True,'nativeLightCount':56,'nightControl':'Native StreetLightObject child; LightsOff forbidden; no runtime companion required','crcPassed':True,'validation':'pending native reload/day/night'}
(out/'release.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
